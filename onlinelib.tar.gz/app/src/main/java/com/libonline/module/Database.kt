package com.libonline.module



data class Database (
     val serverStatus: String?,
     val noticeMode: String?,
     val dataClearMode: String?,
     val serverMessage: String?,
     val openTime: String?,
     val libs: String?,
     val noticeTitle: String?,
     val noticeBody: String?
)

